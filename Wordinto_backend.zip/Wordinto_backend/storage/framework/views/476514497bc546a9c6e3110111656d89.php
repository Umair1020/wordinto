<!DOCTYPE html>
<html>
<head>
    <title>Payment Confirmation</title>
</head>
<body>
    <h1>Thank you for your payment!</h1>
    <p>Dear <?php echo e($details['senderName']); ?>,</p>
    <p>Your payment of <?php echo e($details['amount']); ?> was successful.</p>
    <p>Thank you for your purchase!</p>
</body>
</html>
<?php /**PATH C:\laragon\www\Wordinto\Wordinto_backend\resources\views/email_templates/user_payment_confirmation.blade.php ENDPATH**/ ?>