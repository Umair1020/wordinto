<!DOCTYPE html>
<html>
<head>
    <title>New Payment Received</title>
</head>
<body>
    <h1>New Payment Received</h1>
    <p>A new payment has been received from <?php echo e($details['senderName']); ?>.</p>
    <p>Amount: <?php echo e($details['amount']); ?></p>
    <p>Receiver's Name: <?php echo e($details['receiverName']); ?></p>
    <p>Receiver's Email: <?php echo e($details['receiverEmail']); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\Wordinto\Wordinto_backend\resources\views/email_templates/admin_payment_notification.blade.php ENDPATH**/ ?>